require 'test_helper'
require 'xmlrpc'

class XmlrpcTest < Test::Unit::TestCase
  def test_that_it_has_a_version_number
    assert ::XMLRPC::VERSION
  end
end
